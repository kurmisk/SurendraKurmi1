﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Views;
using System;
using SQLite;
using System.Linq;
using Android.Content;
using TicTacToeBL;

namespace TicTacToe
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        int totalXWins = 0;
        int totalZeroWins = 0;
        int draw;
        SQLiteConnection conn;
        LinearLayout.LayoutParams paramUser;
        LinearLayout.LayoutParams paramAI;
        LinearLayout.LayoutParams paramDraw;
        View winUserView, winAIView, drawView;
        TextView totalMatches, xWins, drawGames, zeroWins;
        string dbPath;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_main);
            totalMatches = FindViewById<TextView>(Resource.Id.totalmatches);
            winUserView = FindViewById<View>(Resource.Id.winUser);
            winAIView = FindViewById<View>(Resource.Id.winAI);
            drawView = FindViewById<View>(Resource.Id.draw);
            ImageView imglogo = FindViewById<ImageView>(Resource.Id.logoPic);
            Button play = FindViewById<Button>(Resource.Id.btnPlay);
            xWins = FindViewById<TextView>(Resource.Id.xWins);
            drawGames = FindViewById<TextView>(Resource.Id.drawgames);
            zeroWins = FindViewById<TextView>(Resource.Id.zeroWins);
            play.Click += Play_Click;
            imglogo.SetImageResource(Resource.Drawable.logoimage);
            paramUser = new LinearLayout.LayoutParams(0, 25);
            paramAI = new LinearLayout.LayoutParams(0, 25);
            paramDraw = new LinearLayout.LayoutParams(0, 25);
            dbPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData);
            CreatedDatabase();
            SetStatistics();
        }

        private void Play_Click(object sender, EventArgs e)
        {
            Intent i = new Intent(this, typeof(ActivityPlayGame));
            i.PutExtra("DBPath", dbPath);
            StartActivity(i);
        }

        void SetStatistics()
        {
            paramUser.Weight = totalXWins;
            winUserView.LayoutParameters = paramUser;
            paramAI.Weight = totalZeroWins;
            winAIView.LayoutParameters = paramAI;
            paramDraw.Weight = draw;
            drawView.LayoutParameters = paramDraw;
            totalMatches.Text = Convert.ToString(totalXWins + totalZeroWins + draw) + " matches";
            xWins.Text = Convert.ToString(totalXWins);
            zeroWins.Text = Convert.ToString(totalZeroWins);
            drawGames.Text = Convert.ToString(draw);
        }

        public void CreatedDatabase()
        {
            conn = DBConnection.GetObject().GetConnection(dbPath);
            var result = conn.CreateTable<Statistics>();
            GeStatisticstData();
        }
        void GeStatisticstData()
        {
            var data = StatisticsMethods.GetObject().GetData(dbPath);
            totalXWins = (from x in data select x.Cross).Sum();
            totalZeroWins = (from x in data select x.Zero).Sum();
            draw = (from x in data select x.Draw).Sum();
        }
        protected override void OnResume()
        {
            base.OnResume();
            GeStatisticstData();
            SetStatistics();
        }
    } 
}