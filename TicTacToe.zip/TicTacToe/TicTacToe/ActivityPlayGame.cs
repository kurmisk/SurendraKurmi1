﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using SQLite;
using TicTacToeBL;

namespace TicTacToe
{
    [Activity(Label = "ActivityyPlayGame")]
    public class ActivityPlayGame : AppCompatActivity,View.IOnClickListener
    {
        int turn = 1;
        int win = 0;
        int gamov = 0;
        int flagEndGame = 0;
        int flag;
        string displayTurn;
        GridLayout grid;
        Button[,] playBoard = new Button[3, 3];
        int[,] boardMatrix = new int[3,3];
        double [,] probMatrix = new double[3,3];
        TextView playerTurn, hintPlayerOne, hintPlayerTwo;
        string player1Name="User";
        string player2Name="AI";
        string player1Symbol, player2Symbol;
        int moveNumber = 1;
        int counter = 0;
        int player1Win = 0, player2Win = 0, draw = 0;
        int flipValue = 0;
        int level = 0;
        ImageView resultEmoji;
        Android.Support.V7.App.AlertDialog.Builder builder;
        string winingSymbol;
        string dbPath;
        Animation anim;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.PlayScreen);
            dbPath = Intent.GetStringExtra("DBPath") ?? string.Empty;
            builder = new Android.Support.V7.App.AlertDialog.Builder(this);
            grid = FindViewById<GridLayout>(Resource.Id.grid);
            playerTurn = FindViewById<TextView>(Resource.Id.matchStatus);
            TextView playAgain = FindViewById<TextView>(Resource.Id.playAgain);
            TextView done = FindViewById<TextView>(Resource.Id.btnDone);
            hintPlayerOne = FindViewById<TextView>(Resource.Id.hintPlayerOne);
            hintPlayerTwo = FindViewById<TextView>(Resource.Id.hintPlayerTwo);
            resultEmoji = FindViewById<ImageView>(Resource.Id.resultEmoji);
            playAgain.Click += PlayAgain_Click;
            done.Click += Done_Click;
            anim = AnimationUtils.LoadAnimation(this, Resource.Animation.fade_in);
            displayTurn = player1Name + "'s turn (X)";
            player1Symbol = "X";
            player2Symbol = "0";
           
            //playerTurn.Text = displayTurn;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    playBoard[i,j] = (Button)grid.GetChildAt(3 * i + j);
                    playBoard[i, j].SetOnClickListener(this);
                    boardMatrix[i, j] = 0;
                }
            }
            if (flipValue == 1)
            {
                AIPlay();
                turn = 2;
            }
        }

        private void Done_Click(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle("Cancel Game!");
            alert.SetMessage("Want to Cancel the game?");
            alert.SetPositiveButton("Yes", (senderAlert, args) => {
                this.Finish();
            });

            alert.SetNegativeButton("Cancel", (senderAlert, args) => {
                
            });
            alert.Show();
        }

        private void PlayAgain_Click(object sender, EventArgs e)
        {
            if (flipValue == 0)
            {
                hintPlayerOne.SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                hintPlayerTwo.SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                player1Symbol = "X";
                player2Symbol = "0";
            }
            else
            {
                hintPlayerOne.SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                hintPlayerTwo.SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                player1Symbol = "0";
                player2Symbol = "X";
            }
            resultEmoji.SetImageResource(0);
            playerTurn.Text = "";

            StartNewGame(null);
        }

        public async void PlayMove(View view)
        {
            int index = grid.IndexOfChild(view);
            int i = index / 3;
            int j = index % 3;
            flag = 0;
            if (turn == 1 && gamov == 0 && !(playBoard[i, j].Text.Equals("X")) && !(playBoard[i, j].Text.Equals("O")))
            {
                if (flipValue == 0)
                {
                    displayTurn = player2Name + "'s turn (O)";
                    //playerTurn.Text = displayTurn;
                    playBoard[i, j].Text = "X";
                    playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                    boardMatrix[i, j] = 1;
                    turn = 2;
                    moveNumber++;
                    await AIPlay();
                    turn = 1;
                    displayTurn = player1Name + "'s turn (X)";
                    moveNumber++;
                }
            }
            else if (turn == 2 && gamov == 0 && !(playBoard[i, j].Text.Equals("X")) && !(playBoard[i, j].Text.Equals("O")))
            {
                if (flipValue == 1)
                {
                    displayTurn = player2Name + "'s turn (X)";
                    //playerTurn.Text = displayTurn;
                    playBoard[i, j].Text = "O";
                    playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                    boardMatrix[i, j] = 1;
                    turn = 1;
                    moveNumber++;
                    await AIPlay();
                    displayTurn = player1Name + "'s turn (O)";
                    turn = 2;
                    moveNumber++;
                }
            }

            CheckWin();
            if (gamov == 1)
            {
                if (win == 1)
                {
                    //builder.SetMessage(player1Name + " wins!").SetTitle("Game over");
                    playerTurn.Text = "You Win!";
                    winingSymbol = player1Symbol;
                    resultEmoji.SetImageResource(Resource.Drawable.face_happy);
                    InsertResult(0);
                    if (flagEndGame == 0)
                    {
                        player1Win++;
                        counter++;
                    }
                }
                else if (win == 2)
                {
                    //builder.SetMessage(player2Name + " wins!").SetTitle("Game over");
                    playerTurn.Text = "You Lose!";
                    winingSymbol = player2Symbol;
                    resultEmoji.SetImageResource(Resource.Drawable.face_sad);
                    InsertResult(0);
                    if (flagEndGame == 0)
                    {
                        player2Win++;
                        counter++;
                    }
                }
                flagEndGame = 1;
            }
            if (gamov == 0)
            {
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 3; j++)
                    {
                        if (!playBoard[i, j].Text.Equals("X") && !playBoard[i, j].Text.Equals("O"))
                        {
                            flag = 1;
                            break;
                        }
                    }
                }
                if (flag == 0)
                {
                    //builder.SetMessage("It's a draw!").SetTitle("Game over");
                    if (flagEndGame == 0)
                    {
                        counter++;
                        draw++;
                    }
                    flagEndGame = 1;
                    playerTurn.Text = "That's a draw!";
                    resultEmoji.SetImageResource(Resource.Drawable.face_indifferent);
                    InsertResult(1);
                }
            }
        }
        
        public async Task AIPlay()
        {
            int currentTurn = turn;
            int currentMove = moveNumber;
            int i = 0, j = 0;
            int moveChoice = 0;
            int flag = 0;
            int flagGameNotOver = 0;
            if (turn == 1)
            {
                turn = 2;
            }
            else
            {
                turn = 1;
            }
            for (int c = 0; c < 9; c++)
            {
                i = c / 3;
                j = c % 3;
                probMatrix[i,j] = 0;
            }

            for (int c = 0; c < 9; c++)
            {
                i = c / 3;
                j = c % 3;
                if (boardMatrix[i,j] == 0)
                {
                    flagGameNotOver = 1;
                
                    boardMatrix[i,j] = 1;
                    if (flipValue == 1)
                    {
                        playBoard[i, j].Text = "X";
                        playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                    }
                    else
                    {
                        playBoard[i, j].Text = "O";
                        playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                    }
                    if (CheckWinComp() == 2 && flipValue == 0)
                    {
                        flag = 1;
                        playBoard[i, j].Text = " ";
                        boardMatrix[i, j] = 0;
                        break;
                    }
                    else if (CheckWinComp() == 2 && flipValue == 1)
                    {
                        flag = 1;
                        playBoard[i, j].Text = " ";
                        boardMatrix[i, j] = 0;
                        break;
                    }
                    if (CheckWinComp() == 1 && flipValue == 1)
                    {
                        playBoard[i, j].Text = " ";
                        
                        boardMatrix[i, j] = 0;
                        continue;
                    }
                    else if (CheckWinComp() == 1 && flipValue == 0)
                    {
                        playBoard[i, j].Text = " ";
                        
                        boardMatrix[i, j] = 0;
                        continue;
                    }
                    else
                    {
                        level++;
                        probMatrix[i, j] = AIAnalyze();                     
                        level--;
                    }
                    playBoard[i, j].Text = " ";
                    boardMatrix[i, j] = 0;
                }
            }
            if (flagGameNotOver == 0)
            {
                return;
            }
            double maxProb = 0;
            if (flag == 0)
            {
                for (int p = 0; p < 3; p++)
                {
                    for (int q = 0; q < 3; q++)
                    {
                        if (maxProb < probMatrix[p,q])
                        {
                            maxProb = probMatrix[p, q];
                        }
                    }
                }
                for (int p = 0; p < 3; p++)
                {
                    for (int q = 0; q < 3; q++)
                    {
                        if (maxProb == probMatrix[p,q] && boardMatrix[p,q] == 0)
                        {
                            moveChoice = 3 * p + q;
                            break;
                        }
                    }
                }
            }
            else
            {
                moveChoice = 3 * i + j;
            }
            turn = currentTurn;
            moveNumber = currentMove;
            int xCoord = moveChoice / 3;
            int yCoord = moveChoice % 3;
            boardMatrix[xCoord, yCoord] = 1;
            if (flipValue == 0)
            {
                playBoard[xCoord, yCoord].Text = "O";
                playBoard[xCoord, yCoord].SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                displayTurn = player1Name + "'s turn (X)";
                //playerTurn.Text = displayTurn;
            }
            else
            {
                playBoard[xCoord, yCoord].Text = "X";
                playBoard[xCoord, yCoord].SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                displayTurn = player1Name + "'s turn (O)";
                //playerTurn.Text = displayTurn;
            }
        }

        public double AIAnalyze()
        {
            double sum = 0;
            int counter = 0;
            int flagCheckGameNotOver = 0;
            for (int c = 0; c < 4; c++)
            {
                int i = c / 3;
                int j = c % 3;

                if (boardMatrix[i,j] == 0)
                {
                    flagCheckGameNotOver = 1;
                    boardMatrix[i,j] = 1;

                    if (turn == 1)
                    {
                        playBoard[i, j].Text = "X";
                        playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                    }
                    else
                    {
                        playBoard[i, j].Text = "O";
                        playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                    }
                    if (CheckWinComp() == 2 && flipValue == 0)
                    {
                        sum = 1;
                        playBoard[i, j].Text = " ";
                        boardMatrix[i, j] = 0;

                        return sum;
                    }
                    else if (CheckWinComp() == 2 && flipValue == 1)
                    {
                        sum = 1;
                        
                        playBoard[i, j].Text = " ";
                        boardMatrix[i, j] = 0;

                        return sum;
                    }
                    else if (CheckWinComp() == 1 && flipValue == 1)
                    {
                        sum = 0;
                        
                        playBoard[i, j].Text = " ";
                        boardMatrix[i, j] = 0;

                        return sum;
                    }
                    else if (CheckWinComp() == 1 && flipValue == 0)
                    {
                        sum = 0;
                        
                        playBoard[i, j].Text = " ";
                        boardMatrix[i, j] = 0;

                        return sum;
                    }
                    else
                    {
                        counter++;
                        if (turn == 1)
                        {
                            turn = 2;
                        }
                        else
                        {
                            turn = 1;
                        }
                        level++;
                        double value = AIAnalyze();
                        level--;
                        sum += value;
                    }
                    playBoard[i, j].Text = " ";
                    boardMatrix[i, j] = 0;
                    if (turn == 1)
                    {
                        turn = 2;
                    }
                    else
                    {
                        turn = 1;
                    }
                }

            }
            if (flagCheckGameNotOver == 0)
            {
                return 0.5;
            }
            double average = ((double)sum) / ((double)counter);
            return average;
        }

        public int CheckWinComp()
        {
            for (int i = 0; i < 3; i++)
            {
                if (playBoard[i,0].Text.Equals(playBoard[i,1].Text) && playBoard[i,0].Text.Equals(playBoard[i,2].Text))
                {
                    if (playBoard[i,0].Text.Equals("X"))
                    {

                        if (flipValue == 0)
                            return 1;
                        else if (flipValue == 1)
                            return 2;


                    }
                    else if (playBoard[i,0].Text.Equals("O"))
                    {

                        if (flipValue == 0)
                            return 2;
                        else if (flipValue == 1)
                            return 1;

                    }
                }
                if (playBoard[0,i].Text.Equals(playBoard[1,i].Text) && playBoard[0,i].Text.Equals(playBoard[2,i].Text))
                {
                    if (playBoard[0,i].Text.Equals("X"))
                    {

                        if (flipValue == 0)
                            return 1;
                        else if (flipValue == 1)
                            return 2;


                    }
                    else if (playBoard[0,i].Text.Equals("O"))
                    {

                        if (flipValue == 0)
                            return 2;
                        else if (flipValue == 1)
                            return 1;

                    }
                }
            }
            if (playBoard[0,0].Text.Equals(playBoard[1,1].Text) && playBoard[0,0].Text.Equals(playBoard[2,2].Text))
            {
                if (playBoard[0,0].Text.Equals("X"))
                {

                    if (flipValue == 0)
                        return 1;
                    else if (flipValue == 1)
                        return 2;


                }
                else if (playBoard[0,0].Text.Equals("O"))
                {

                    if (flipValue == 0)
                        return 2;
                    else if (flipValue == 1)
                        return 1;

                }
            }
            if (playBoard[0,2].Text.Equals(playBoard[1,1].Text) && playBoard[0,2].Text.Equals(playBoard[2,0].Text))
            {
                if (playBoard[0,2].Text.Equals("X"))
                {

                    if (flipValue == 0)
                        return 1;
                    else if (flipValue == 1)
                        return 2;


                }
                else if (playBoard[0,2].Text.Equals("O"))
                {

                    if (flipValue == 0)
                        return 2;
                    else if (flipValue == 1)
                        return 1;

                }
            }
            return 0;
        }

        public void CheckWin()
        {
            for (int i = 0; i < 3; i++)
            {
                if (playBoard[i,0].Text.Equals(playBoard[i,1].Text) && playBoard[i,0].Text.Equals(playBoard[i,2].Text))
                {
                    if (playBoard[i,0].Text.Equals("X"))
                    {
                        gamov = 1;
                        if (flipValue == 0)
                            win = 1;
                        else if (flipValue == 1)
                            win = 2;


                    }
                    else if (playBoard[i,0].Text.Equals("O"))
                    {
                        gamov = 1;
                        if (flipValue == 0)
                            win = 2;
                        else if (flipValue == 1)
                            win = 1;

                    }
                    if (!playBoard[i,0].Text.Equals(" "))
                    {
                        playBoard[i, 0].StartAnimation(anim);
                        playBoard[i, 1].StartAnimation(anim);
                        playBoard[i, 2].StartAnimation(anim);

                    }

                }
                if (playBoard[0,i].Text.Equals(playBoard[1,i].Text) && playBoard[0,i].Text.Equals(playBoard[2,i].Text))
                {
                    if (playBoard[0,i].Text.Equals("X"))
                    {
                        gamov = 1;
                        if (flipValue == 0)
                            win = 1;
                        else if (flipValue == 1)
                            win = 2;


                    }
                    else if (playBoard[0,i].Text.Equals("O"))
                    {
                        gamov = 1;
                        if (flipValue == 0)
                            win = 2;
                        else if (flipValue == 1)
                            win = 1;

                    }
                    if (!playBoard[0,i].Text.Equals(" "))
                    {
                        playBoard[0,i].StartAnimation(anim);
                        playBoard[1,i].StartAnimation(anim);
                        playBoard[2,i].StartAnimation(anim);
                    }
                }
            }
            if (playBoard[0,0].Text.Equals(playBoard[1,1].Text) && playBoard[0,0].Text.Equals(playBoard[2,2].Text))
            {
                if (playBoard[0,0].Text.Equals("X"))
                {
                    gamov = 1;
                    if (flipValue == 0)
                        win = 1;
                    else if (flipValue == 1)
                        win = 2;


                }
                else if (playBoard[0,0].Text.Equals("O"))
                {
                    gamov = 1;
                    if (flipValue == 0)
                        win = 2;
                    else if (flipValue == 1)
                        win = 1;

                }
                if (!playBoard[0,0].Text.Equals(" "))
                {
                    playBoard[0,0].StartAnimation(anim);
                    playBoard[1,1].StartAnimation(anim);
                    playBoard[2,2].StartAnimation(anim);
                }


            }
            if (playBoard[0,2].Text.Equals(playBoard[1,1].Text) && playBoard[0,2].Text.Equals(playBoard[2,0].Text))
            {
                if (playBoard[0,2].Text.Equals("X"))
                {
                    gamov = 1;
                    if (flipValue == 0)
                        win = 1;
                    else if (flipValue == 1)
                        win = 2;


                }
                else if (playBoard[0,2].Text.Equals("O"))
                {
                    gamov = 1;
                    if (flipValue == 0)
                        win = 2;
                    else if (flipValue == 1)
                        win = 1;

                }
                if (!playBoard[2,0].Text.Equals(" "))
                {
                    playBoard[2,0].StartAnimation(anim);
                    playBoard[1,1].StartAnimation(anim);
                    playBoard[0,2].StartAnimation(anim);
                }
            }
        }

        public void StartNewGame(View view)
        {

            win = 0;
            gamov = 0;
            turn = 1;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    playBoard[i, j].Text = " ";
                    playBoard[i, j].ClearAnimation();
                    playBoard[i, j].SetTextColor(Color.White);
                    boardMatrix[i, j] = 0;
                }
            }

            if (flipValue == 0)
            {
                if (flagEndGame == 1)
                {
                    flipValue = 1;
                    displayTurn = player2Name + "'s turn (X)";
                    //playerTurn.Text = displayTurn;
                }
                else
                {
                    displayTurn = player1Name + "'s turn (X)";
                    //playerTurn.Text = displayTurn;
                }
            }
            else if (flipValue == 1)
            {
                if (flagEndGame == 1)
                {
                    flipValue = 0;
                    displayTurn = player1Name + "'s turn (X)";
                    //playerTurn.Text = displayTurn;
                }
                else
                {
                    displayTurn = player2Name + "'s turn (X)";
                    //playerTurn.Text = displayTurn;
                }
            }
            displayTurn = "";
            flagEndGame = 0;
            if (flipValue == 1)
            {
                RandomPlay();  
                turn = 2;
            }
            if (flipValue == 0)
            {
                hintPlayerOne.SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                hintPlayerTwo.SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                player1Symbol = "X";
                player2Symbol = "0";
            }
            else
            {
                hintPlayerOne.SetTextColor(Resources.GetColor(Resource.Color.colorzero));
                hintPlayerTwo.SetTextColor(Resources.GetColor(Resource.Color.colorcross));
                player1Symbol = "0";
                player2Symbol = "X";
            }
        }

        public void RandomPlay()
        {
            Random random1 = new Random();
            int random = (int)(random1.NextDouble() * 9);
            int i = random / 3;
            int j = random % 3;
            playBoard[i, j].Text = "X";
            playBoard[i, j].SetTextColor(Resources.GetColor(Resource.Color.colorcross));
            boardMatrix[i, j] = 1;
        }

        public void OnClick(View v)
        {
            PlayMove(v);
        }

        void InsertResult(int isDraw)
        {
            Statistics objStatistics = new Statistics();
            if (!string.IsNullOrEmpty(winingSymbol) && winingSymbol.Equals("X"))
            {
                objStatistics.Cross = 1;
                objStatistics.Zero = 0;
            }
            else if (!string.IsNullOrEmpty(winingSymbol) && winingSymbol.Equals("0"))
            {
                objStatistics.Zero = 1;
                objStatistics.Cross = 0;
            }
            objStatistics.Draw = isDraw;
            int isInserted = 0;
            isInserted = StatisticsMethods.GetObject().InsertData(objStatistics, dbPath);
        }

    }
}
