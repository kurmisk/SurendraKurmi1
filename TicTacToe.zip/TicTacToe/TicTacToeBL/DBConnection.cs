﻿using System;
using System.IO;
using SQLite;

namespace TicTacToeBL
{
    public class DBConnection
    {
        protected static DBConnection _obj;
        private DBConnection()
        {
        }
        public static DBConnection GetObject()
        {
            if (_obj == null)
            {
                _obj = new DBConnection();
            }
            return _obj;
        }
        public SQLiteConnection GetConnection(string dbpath)
        {
            var dbase = "Mydatabase";
            var path = Path.Combine(dbpath, dbase);
            var connection = new SQLiteConnection(path);
            return connection;
        }
    }
}
