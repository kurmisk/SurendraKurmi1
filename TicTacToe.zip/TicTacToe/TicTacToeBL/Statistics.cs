﻿using System;
using SQLite;

namespace TicTacToeBL
{
    public class Statistics
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public int Cross { get; set; }
        public int Zero { get; set; }
        public int Draw { get; set; }
    }
}
