﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TicTacToeBL
{
    public class StatisticsMethods
    {
        protected static StatisticsMethods _obj;
        private StatisticsMethods()
        {

        }
        public static StatisticsMethods GetObject()
        {
            if (_obj == null)
            {
                _obj = new StatisticsMethods();
            }
            return _obj;
        }

        public List<Statistics> GetData(string dbpath)
        {
            var conn = DBConnection.GetObject().GetConnection(dbpath);
            var result = (from x in conn.Table<Statistics>() select x).ToList();
            return result;
        }

        public int InsertData(Statistics obj, string dbPath)
        {
            int x = 0;
            var conn = DBConnection.GetObject().GetConnection(dbPath);
            try
            {
                x = conn.Insert(obj);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return x;
        }
    }
}
